"""Load cleaned CSV into SQLite using the DDL schema."""
import sqlite3
import pandas as pd
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
DB   = BASE / "marketing.db"
DDL  = BASE / "sql" / "01_ddl.sql"
CSV  = BASE / "data" / "processed" / "marketing_clean.csv"

print(f"[LOAD] CSV -> {CSV}")
df = pd.read_csv(CSV)
print(f"[LOAD] shape = {df.shape}")

# Safety: make sure all DDL columns exist in the CSV
expected_cols = [
    "ID","Year_Birth","Age","Education","Marital_Status","Income",
    "Kidhome","Teenhome","Children","Country","Dt_Customer",
    "Customer_Tenure_Days","Recency",
    "MntWines","MntFruits","MntMeatProducts","MntFishProducts",
    "MntSweetProducts","MntGoldProds","Total_Spend",
    "NumDealsPurchases","NumWebPurchases","NumCatalogPurchases",
    "NumStorePurchases","Total_Purchases","NumWebVisitsMonth",
    "AcceptedCmp1","AcceptedCmp2","AcceptedCmp3","AcceptedCmp4",
    "AcceptedCmp5","TotalAcceptedCmp","Response","Complain",
    "Age_Band","Income_Band","Spend_Band",
    "IsHighIncome","IsYoung","IsResponder","IsHighWebEngagement",
    "IsFamily","IsHighSpender","Primary_Segment"
]

missing = [c for c in expected_cols if c not in df.columns]
if missing:
    print(f"[WARN] missing columns -> {missing}")
    for c in missing:
        df[c] = None          # add them as NULL so insert works

# Keep only columns the table expects (in the right order)
df = df[expected_cols]

# connect + build schema
con = sqlite3.connect(DB)
with open(DDL, "r", encoding="utf-8") as f:
    con.executescript(f.read())
print("[SQL] schema created")

df.to_sql("customers", con, if_exists="append", index=False)
print("[SQL] data inserted")

n = con.execute("SELECT COUNT(*) FROM customers").fetchone()[0]
print(f"[SQL] rows in table = {n}")
con.close()

print(f"✅ DB READY -> {DB}")