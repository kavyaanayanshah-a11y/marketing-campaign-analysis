"""
Marketing Campaign Analysis - End to End Pipeline
Sections:
 1. Load
 2. Clean
 3. Feature Engineering
 4. EDA (saves charts)
 5. Rule-Based Segmentation
 6. Export
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_style("whitegrid")

RAW_PATH   = "data/raw/marketing_data.csv"
DICT_PATH  = "data/raw/marketing_data_dictionary.csv"
OUT_PATH   = "data/processed/marketing_clean.csv"
FIG_DIR    = "reports/figures"
REFERENCE_DATE = pd.Timestamp("2024-01-01")   # fixed reference for reproducibility

MNT_COLS      = ["MntWines","MntFruits","MntMeatProducts",
                 "MntFishProducts","MntSweetProducts","MntGoldProds"]
PURCHASE_COLS = ["NumDealsPurchases","NumWebPurchases",
                 "NumCatalogPurchases","NumStorePurchases"]
CMP_COLS      = ["AcceptedCmp1","AcceptedCmp2","AcceptedCmp3",
                 "AcceptedCmp4","AcceptedCmp5"]

os.makedirs("data/processed", exist_ok=True)
os.makedirs(FIG_DIR, exist_ok=True)


# ============================================================
# 1. LOAD
# ============================================================
def load_raw(path=RAW_PATH):
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    print(f"[LOAD] shape = {df.shape}")
    return df


def show_dictionary(path=DICT_PATH):
    try:
        d = pd.read_csv(path)
        print("\n[DICTIONARY] columns:", list(d.columns))
        print(d.head(10).to_string())
    except Exception as e:
        print("[DICTIONARY] skipped:", e)


# ============================================================
# 2. CLEAN
# ============================================================
def clean_income(df):
    """Income sometimes arrives as '$52,000' string -> float"""
    df = df.copy()
    if df["Income"].dtype == object:
        df["Income"] = (df["Income"].astype(str)
                        .str.replace("$", "", regex=False)
                        .str.replace(",", "", regex=False)
                        .str.strip())
    df["Income"] = pd.to_numeric(df["Income"], errors="coerce")
    return df


def clean_categoricals(df):
    df = df.copy()

    # Education normalisation
    df["Education"] = df["Education"].replace({"2n Cycle": "Master"})

    # Marital status normalisation
    df["Marital_Status"] = df["Marital_Status"].replace({
        "Alone": "Single", "Absurd": "Other", "YOLO": "Other"
    })

    # Country (some dataset versions don't have it)
    if "Country" not in df.columns:
        df["Country"] = "Unknown"
        print("[WARN] 'Country' column missing -> set to 'Unknown'")
    df["Country"] = df["Country"].fillna("Unknown").astype(str).str.strip()

    # Drop constant columns if present
    for c in ["Z_CostContact", "Z_Revenue"]:
        if c in df.columns:
            df.drop(columns=c, inplace=True)

    return df


def impute_income(df):
    """Group-median imputation: Education + Marital_Status, fallback global median"""
    df = df.copy()
    grp_med = df.groupby(["Education", "Marital_Status"])["Income"].transform("median")
    df["Income"] = df["Income"].fillna(grp_med)
    df["Income"] = df["Income"].fillna(df["Income"].median())
    return df


def parse_dates(df):
    df = df.copy()
    df["Dt_Customer"] = pd.to_datetime(df["Dt_Customer"], errors="coerce")
    # If parse looks wrong, try dayfirst
    if df["Dt_Customer"].isna().mean() > 0.5:
        df["Dt_Customer"] = pd.to_datetime(df["Dt_Customer"], errors="coerce", dayfirst=True)
    df["Dt_Customer"] = df["Dt_Customer"].fillna(df["Dt_Customer"].median())
    return df


def remove_outliers(df):
    """Remove unrealistic ages and extreme income"""
    df = df.copy()
    df["Age"] = REFERENCE_DATE.year - df["Year_Birth"]
    before = len(df)
    df = df[(df["Age"] >= 18) & (df["Age"] <= 90)]
    df = df[df["Income"] <= 200000]
    print(f"[OUTLIERS] removed {before - len(df)} rows")
    return df.reset_index(drop=True)


# ============================================================
# 3. FEATURE ENGINEERING
# ============================================================
def add_features(df):
    df = df.copy()

    df["Age"]              = REFERENCE_DATE.year - df["Year_Birth"]
    df["Total_Spend"]      = df[MNT_COLS].sum(axis=1)
    df["Total_Purchases"]  = df[PURCHASE_COLS].sum(axis=1)
    df["Children"]         = df["Kidhome"] + df["Teenhome"]
    df["TotalAcceptedCmp"] = df[CMP_COLS].sum(axis=1)
    df["Customer_Tenure_Days"] = (REFERENCE_DATE - df["Dt_Customer"]).dt.days

    # Bands for SQL grouping / dashboard filters
    df["Age_Band"] = pd.cut(df["Age"],
                            bins=[17, 29, 39, 49, 59, 69, 100],
                            labels=["18-29","30-39","40-49","50-59","60-69","70+"])

    df["Income_Band"] = pd.cut(df["Income"],
                               bins=[-1, 30000, 50000, 75000, 100000, np.inf],
                               labels=["<30K","30K-50K","50K-75K","75K-100K","100K+"])

    # rank() first -> avoids duplicate-bin-edge errors in qcut
    df["Spend_Band"] = pd.qcut(df["Total_Spend"].rank(method="first"), 5,
                               labels=["Very Low","Low","Medium","High","Very High"])

    return df


# ============================================================
# 4. RULE-BASED SEGMENTATION
# ============================================================
def add_segments(df):
    df = df.copy()
    p90_spend = df["Total_Spend"].quantile(0.90)
    print(f"[SEGMENT] 90th percentile spend = {p90_spend:.2f}")

    df["IsHighIncome"]        = (df["Income"] > 75000).astype(int)
    df["IsYoung"]             = (df["Age"] < 30).astype(int)
    df["IsResponder"]         = (df["Response"] == 1).astype(int)
    df["IsHighWebEngagement"] = (df["NumWebVisitsMonth"] > 5).astype(int)
    df["IsFamily"]            = (df["Children"] > 0).astype(int)
    df["IsHighSpender"]       = (df["Total_Spend"] > p90_spend).astype(int)

    conditions = [
        df["IsHighSpender"] == 1,
        df["IsResponder"] == 1,
        df["IsHighIncome"] == 1,
        df["IsFamily"] == 1,
        df["IsYoung"] == 1,
        df["IsHighWebEngagement"] == 1,
    ]
    choices = ["High Spender","Campaign Responder","High Income",
               "Family Customer","Young Customer","High Web Engagement"]

    df["Primary_Segment"] = np.select(conditions, choices,
                                      default="Regular / Low Engagement")
    return df


# ============================================================
# 5. EDA
# ============================================================
def run_eda(df):
    print("\n===== EDA SUMMARY =====")
    print(df[["Age","Income","Total_Spend","Recency","NumWebVisitsMonth"]].describe().round(2))

    # Univariate
    fig, ax = plt.subplots(1, 3, figsize=(16, 4))
    sns.histplot(df["Age"], bins=25, ax=ax[0], color="#4C72B0"); ax[0].set_title("Age Distribution")
    sns.histplot(df["Income"], bins=30, ax=ax[1], color="#55A868"); ax[1].set_title("Income Distribution")
    sns.histplot(df["Total_Spend"], bins=30, ax=ax[2], color="#C44E52"); ax[2].set_title("Total Spend Distribution")
    plt.tight_layout(); plt.savefig(f"{FIG_DIR}/01_univariate.png", dpi=110); plt.close()

    # Response vs Income
    plt.figure(figsize=(8,4))
    sns.boxplot(data=df, x="Response", y="Income", palette="Set2")
    plt.title("Income vs Campaign Response")
    plt.tight_layout(); plt.savefig(f"{FIG_DIR}/02_response_income.png", dpi=110); plt.close()

    # Product spend totals
    prod = df[MNT_COLS].sum().sort_values(ascending=False)
    plt.figure(figsize=(9,4))
    prod.plot(kind="bar", color="#8172B2")
    plt.title("Total Spend by Product Category"); plt.ylabel("Revenue")
    plt.tight_layout(); plt.savefig(f"{FIG_DIR}/03_product_spend.png", dpi=110); plt.close()

    # Segment response rate
    seg = (df.groupby("Primary_Segment")["Response"].mean() * 100).sort_values(ascending=False)
    plt.figure(figsize=(10,4))
    seg.plot(kind="bar", color="#4C72B0")
    plt.title("Response Rate (%) by Segment"); plt.ylabel("%")
    plt.tight_layout(); plt.savefig(f"{FIG_DIR}/04_segment_response.png", dpi=110); plt.close()

    # Correlation heatmap
    plt.figure(figsize=(10,7))
    num = df[["Age","Income","Total_Spend","Total_Purchases","Recency",
              "NumWebVisitsMonth","TotalAcceptedCmp","Response"]]
    sns.heatmap(num.corr(), annot=True, fmt=".2f", cmap="coolwarm", center=0)
    plt.title("Correlation Heatmap")
    plt.tight_layout(); plt.savefig(f"{FIG_DIR}/05_correlation.png", dpi=110); plt.close()

    print(f"[EDA] charts saved to {FIG_DIR}/")


# ============================================================
# 6. EXPORT
# ============================================================
def export(df, path=OUT_PATH):
    out = df.copy()
    out["Dt_Customer"] = out["Dt_Customer"].dt.strftime("%Y-%m-%d")
    for c in ["Age_Band","Income_Band","Spend_Band"]:
        out[c] = out[c].astype(str)
    out.to_csv(path, index=False)
    print(f"[EXPORT] {path}  shape={out.shape}")


# ============================================================
# MAIN
# ============================================================
if __name__ == "__main__":
    show_dictionary()
    df = load_raw()
    df = clean_income(df)
    df = clean_categoricals(df)
    df = parse_dates(df)
    df = impute_income(df)
    df = remove_outliers(df)
    df = add_features(df)
    df = add_segments(df)
    run_eda(df)
    export(df)
    print("\n✅ PIPELINE COMPLETE")