import sqlite3
from pathlib import Path
import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px

# ------------------------------------------------------------------
# CONFIG
# ------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH  = BASE_DIR / "marketing.db"

st.set_page_config(
    page_title="Marketing Campaign Analytics",
    page_icon="📈",
    layout="wide"
)

# ------------------------------------------------------------------
# DATA LOADER
# ------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def load_data():
    con = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query("SELECT * FROM customers", con)
    con.close()
    return df


try:
    df = load_data()
except Exception as e:
    st.error(f"❌ Could not load database: {e}")
    st.info("Make sure you ran:  python src\\load_to_sql.py")
    st.stop()

# ------------------------------------------------------------------
# SIDEBAR FILTERS
# ------------------------------------------------------------------
st.sidebar.title("🎯 Filters")

countries = sorted(df["Country"].dropna().unique().tolist())
sel_country = st.sidebar.multiselect("Country", countries, default=countries)

educations = sorted(df["Education"].dropna().unique().tolist())
sel_edu = st.sidebar.multiselect("Education", educations, default=educations)

maritals = sorted(df["Marital_Status"].dropna().unique().tolist())
sel_marital = st.sidebar.multiselect("Marital Status", maritals, default=maritals)

age_bands = ["18-29", "30-39", "40-49", "50-59", "60-69", "70+"]
sel_age = st.sidebar.multiselect("Age Band", age_bands, default=age_bands)

income_bands = ["<30K", "30K-50K", "50K-75K", "75K-100K", "100K+"]
sel_income = st.sidebar.multiselect("Income Band", income_bands, default=income_bands)

segments = sorted(df["Primary_Segment"].dropna().unique().tolist())
sel_seg = st.sidebar.multiselect("Primary Segment", segments, default=segments)

children_opt = st.sidebar.radio("Children", ["All", "Has Children", "No Children"])

# ------------------------------------------------------------------
# APPLY FILTERS
# ------------------------------------------------------------------
f = df[
    df["Country"].isin(sel_country)
    & df["Education"].isin(sel_edu)
    & df["Marital_Status"].isin(sel_marital)
    & df["Age_Band"].isin(sel_age)
    & df["Income_Band"].isin(sel_income)
    & df["Primary_Segment"].isin(sel_seg)
].copy()

if children_opt == "Has Children":
    f = f[f["Children"] > 0]
elif children_opt == "No Children":
    f = f[f["Children"] == 0]

if f.empty:
    st.warning("⚠️ No data for the selected filters. Please widen your selection.")
    st.stop()

# ------------------------------------------------------------------
# HEADER + KPIs
# ------------------------------------------------------------------
st.title("📈 Marketing Campaign Analytics Dashboard")
st.caption("Retail customer segmentation, spending patterns and campaign response")

k1, k2, k3, k4, k5, k6 = st.columns(6)
k1.metric("Customers", f"{len(f):,}")
k2.metric("Avg Income", f"${f['Income'].mean():,.0f}")
k3.metric("Avg Spend", f"${f['Total_Spend'].mean():,.0f}")
k4.metric("Response Rate", f"{100 * f['Response'].mean():.2f}%")
k5.metric("Avg Web Visits/mo", f"{f['NumWebVisitsMonth'].mean():.1f}")
k6.metric("Avg Recency (days)", f"{f['Recency'].mean():.0f}")

st.divider()

# ------------------------------------------------------------------
# TABS
# ------------------------------------------------------------------
tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(
    ["🎯 Campaigns", "👥 Demographics", "💰 Spending",
     "🛒 Channels", "🧩 Segments", "📄 Data & Insights"]
)

# ---------------- TAB 1 : CAMPAIGNS ----------------
with tab1:
    st.subheader("Campaign Acceptance Rate")
    cmp_cols = ["AcceptedCmp1", "AcceptedCmp2", "AcceptedCmp3",
                "AcceptedCmp4", "AcceptedCmp5", "Response"]
    rates = (f[cmp_cols].mean() * 100).reset_index()
    rates.columns = ["Campaign", "Acceptance Rate (%)"]
    fig = px.bar(
        rates, x="Campaign", y="Acceptance Rate (%)",
        text_auto=".2f", color="Acceptance Rate (%)",
        color_continuous_scale="Blues"
    )
    st.plotly_chart(fig, use_container_width=True)
    st.info("💡 Takeaway: The last campaign ('Response') generally outperforms "
            "earlier campaigns — recent targeting is improving.")

    st.subheader("Response Rate by Segment")
    seg_resp = (
        f.groupby("Primary_Segment")["Response"].mean() * 100
    ).sort_values(ascending=False).reset_index()
    seg_resp.columns = ["Segment", "Response Rate (%)"]
    fig2 = px.bar(
        seg_resp, x="Response Rate (%)", y="Segment",
        orientation="h", text_auto=".2f",
        color="Response Rate (%)", color_continuous_scale="Teal"
    )
    st.plotly_chart(fig2, use_container_width=True)


# ---------------- TAB 2 : DEMOGRAPHICS ----------------
with tab2:
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Age Distribution")
        st.plotly_chart(
            px.histogram(f, x="Age", nbins=30, color="Response", barmode="overlay"),
            use_container_width=True
        )
    with c2:
        st.subheader("Income Distribution")
        st.plotly_chart(
            px.histogram(f, x="Income", nbins=30, color="Response", barmode="overlay"),
            use_container_width=True
        )

    c3, c4 = st.columns(2)
    with c3:
        st.subheader("Response Rate by Education")
        e = (f.groupby("Education")["Response"].mean() * 100).reset_index()
        e.columns = ["Education", "Response Rate (%)"]
        st.plotly_chart(
            px.bar(e, x="Education", y="Response Rate (%)",
                   text_auto=".2f", color="Education"),
            use_container_width=True
        )
    with c4:
        st.subheader("Response Rate by Marital Status")
        m = (f.groupby("Marital_Status")["Response"].mean() * 100).reset_index()
        m.columns = ["Marital_Status", "Response Rate (%)"]
        st.plotly_chart(
            px.bar(m, x="Marital_Status", y="Response Rate (%)",
                   text_auto=".2f", color="Marital_Status"),
            use_container_width=True
        )

    st.subheader("Response Rate by Country")
    cn = (f.groupby("Country")["Response"].mean() * 100).reset_index()
    cn.columns = ["Country", "Response Rate (%)"]
    st.plotly_chart(
        px.bar(cn, x="Country", y="Response Rate (%)", text_auto=".2f"),
        use_container_width=True
    )


# ---------------- TAB 3 : SPENDING ----------------
with tab3:
    mnt = {
        "MntWines": "Wines", "MntFruits": "Fruits",
        "MntMeatProducts": "Meat", "MntFishProducts": "Fish",
        "MntSweetProducts": "Sweets", "MntGoldProds": "Gold"
    }

    st.subheader("Total Revenue by Product Category")
    prod = f[list(mnt.keys())].sum().rename(index=mnt).reset_index()
    prod.columns = ["Product", "Total Spend"]
    st.plotly_chart(
        px.bar(prod.sort_values("Total Spend", ascending=False),
               x="Product", y="Total Spend", color="Product", text_auto=".2s"),
        use_container_width=True
    )

    st.subheader("Average Spend by Age Band & Product")
    grp = f.groupby("Age_Band")[list(mnt.keys())].mean().rename(columns=mnt).reset_index()
    grp_m = grp.melt(id_vars="Age_Band", var_name="Product", value_name="Avg Spend")
    st.plotly_chart(
        px.bar(grp_m, x="Age_Band", y="Avg Spend", color="Product", barmode="group"),
        use_container_width=True
    )

    st.subheader("Total Spend by Income Band")
    ib = f.groupby("Income_Band")["Total_Spend"].mean().reset_index()
    ib.columns = ["Income_Band", "Avg Total Spend"]
    st.plotly_chart(
        px.bar(ib, x="Income_Band", y="Avg Total Spend",
               color="Avg Total Spend", color_continuous_scale="Sunsetdark",
               text_auto=".2s"),
        use_container_width=True
    )


# ---------------- TAB 4 : CHANNELS ----------------
with tab4:
    st.subheader("Average Purchases by Channel (per customer)")
    ch_cols = ["NumWebPurchases", "NumStorePurchases",
               "NumCatalogPurchases", "NumDealsPurchases"]
    ch = f[ch_cols].mean().reset_index()
    ch.columns = ["Channel", "Avg Purchases"]
    ch["Channel"] = (ch["Channel"]
                     .str.replace("Num", "", regex=False)
                     .str.replace("Purchases", "", regex=False))
    st.plotly_chart(
        px.bar(ch, x="Channel", y="Avg Purchases",
               color="Channel", text_auto=".2f"),
        use_container_width=True
    )

    st.subheader("Web Visits vs Total Spend")
    st.plotly_chart(
        px.scatter(
            f, x="NumWebVisitsMonth", y="Total_Spend",
            color="Response", size="Total_Purchases",
            hover_data=["Income", "Age", "Primary_Segment"],
            color_continuous_scale="Viridis"
        ),
        use_container_width=True
    )

    st.subheader("Channel Usage by Spend Band")
    cb = f.groupby("Spend_Band")[ch_cols].mean().reset_index()
    cb_m = cb.melt(id_vars="Spend_Band", var_name="Channel", value_name="Avg Purchases")
    st.plotly_chart(
        px.bar(cb_m, x="Spend_Band", y="Avg Purchases",
               color="Channel", barmode="group"),
        use_container_width=True
    )


# ---------------- TAB 5 : SEGMENTS ----------------
with tab5:
    st.subheader("Segment KPI Table")
    kpi = (
        f.groupby("Primary_Segment")
        .agg(
            Customers=("ID", "count"),
            Avg_Income=("Income", "mean"),
            Avg_Age=("Age", "mean"),
            Avg_Spend=("Total_Spend", "mean"),
            Avg_Purchases=("Total_Purchases", "mean"),
            Avg_Web_Visits=("NumWebVisitsMonth", "mean"),
            Response_Rate=("Response", lambda s: 100 * s.mean())
        )
        .round(2)
        .reset_index()
    )
    st.dataframe(kpi, use_container_width=True)

    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Customers per Segment")
        st.plotly_chart(
            px.pie(kpi, names="Primary_Segment",
                   values="Customers", hole=0.45),
            use_container_width=True
        )
    with c2:
        st.subheader("Avg Spend vs Response Rate")
        st.plotly_chart(
            px.scatter(kpi, x="Avg_Spend", y="Response_Rate",
                       size="Customers", color="Primary_Segment",
                       hover_name="Primary_Segment"),
            use_container_width=True
        )

    st.subheader("Segment × Income Band Heatmap")
    hm = f.pivot_table(index="Primary_Segment", columns="Income_Band",
                       values="ID", aggfunc="count", fill_value=0)
    st.plotly_chart(
        px.imshow(hm, text_auto=True, aspect="auto",
                  color_continuous_scale="Blues"),
        use_container_width=True
    )


# ---------------- TAB 6 : DATA & INSIGHTS ----------------
with tab6:
    st.subheader("Filtered Data Preview")
    st.dataframe(f.head(300), use_container_width=True)

    st.download_button(
        "⬇️ Download Filtered CSV",
        f.to_csv(index=False).encode("utf-8"),
        "filtered_marketing_data.csv",
        "text/csv"
    )

    st.subheader("Auto-Generated Insights")

    top_seg     = kpi.sort_values("Response_Rate", ascending=False).iloc[0]
    top_spend   = kpi.sort_values("Avg_Spend", ascending=False).iloc[0]
    overall_pct = 100 * f["Response"].mean()

    st.success(
        "🏆 Highest response segment: "
        + str(top_seg["Primary_Segment"])
        + " — "
        + f"{top_seg['Response_Rate']:.2f}"
        + "%"
    )
    st.success(
        "💰 Highest spending segment: "
        + str(top_spend["Primary_Segment"])
        + " — avg $"
        + f"{top_spend['Avg_Spend']:,.0f}"
    )
    st.info(
        "📌 Overall response rate for current filters: "
        + f"{overall_pct:.2f}"
        + "%"
    )