-- ============================================================
-- Q1. Overall KPIs
-- ============================================================
SELECT
    COUNT(*)                                  AS total_customers,
    ROUND(AVG(Income), 2)                     AS avg_income,
    ROUND(AVG(Total_Spend), 2)                AS avg_total_spend,
    ROUND(AVG(Total_Purchases), 2)            AS avg_purchases,
    ROUND(AVG(Recency), 1)                    AS avg_recency_days,
    ROUND(AVG(NumWebVisitsMonth), 2)          AS avg_web_visits,
    ROUND(100.0 * SUM(Response) / COUNT(*), 2) AS response_rate_pct
FROM customers;


-- ============================================================
-- Q2. Campaign-wise acceptance rate
-- ============================================================
SELECT 'AcceptedCmp1' AS campaign, SUM(AcceptedCmp1) AS acceptors,
       ROUND(100.0*SUM(AcceptedCmp1)/COUNT(*),2) AS rate_pct FROM customers
UNION ALL SELECT 'AcceptedCmp2', SUM(AcceptedCmp2),
       ROUND(100.0*SUM(AcceptedCmp2)/COUNT(*),2) FROM customers
UNION ALL SELECT 'AcceptedCmp3', SUM(AcceptedCmp3),
       ROUND(100.0*SUM(AcceptedCmp3)/COUNT(*),2) FROM customers
UNION ALL SELECT 'AcceptedCmp4', SUM(AcceptedCmp4),
       ROUND(100.0*SUM(AcceptedCmp4)/COUNT(*),2) FROM customers
UNION ALL SELECT 'AcceptedCmp5', SUM(AcceptedCmp5),
       ROUND(100.0*SUM(AcceptedCmp5)/COUNT(*),2) FROM customers
UNION ALL SELECT 'Response (Last)', SUM(Response),
       ROUND(100.0*SUM(Response)/COUNT(*),2) FROM customers
ORDER BY rate_pct DESC;


-- ============================================================
-- Q3. Response rate by Income Band
-- ============================================================
SELECT Income_Band,
       COUNT(*)                                   AS customers,
       ROUND(AVG(Total_Spend), 0)                 AS avg_spend,
       ROUND(100.0 * SUM(Response) / COUNT(*), 2) AS response_rate_pct
FROM customers
GROUP BY Income_Band
ORDER BY response_rate_pct DESC;


-- ============================================================
-- Q4. Segment-level KPI summary (CORE TABLE FOR DASHBOARD)
-- ============================================================
SELECT Primary_Segment,
       COUNT(*)                                   AS customers,
       ROUND(AVG(Income), 0)                      AS avg_income,
       ROUND(AVG(Age), 1)                         AS avg_age,
       ROUND(AVG(Total_Spend), 0)                 AS avg_spend,
       ROUND(AVG(Total_Purchases), 1)             AS avg_purchases,
       ROUND(AVG(NumWebVisitsMonth), 1)           AS avg_web_visits,
       ROUND(100.0 * SUM(Response) / COUNT(*), 2) AS response_rate_pct
FROM customers
GROUP BY Primary_Segment
ORDER BY avg_spend DESC;


-- ============================================================
-- Q5. Channel usage by Spend Band
-- ============================================================
SELECT Spend_Band,
       ROUND(AVG(NumWebPurchases), 2)     AS web,
       ROUND(AVG(NumStorePurchases), 2)   AS store,
       ROUND(AVG(NumCatalogPurchases), 2) AS catalog,
       ROUND(AVG(NumDealsPurchases), 2)   AS deals,
       ROUND(AVG(NumWebVisitsMonth), 2)   AS web_visits
FROM customers
GROUP BY Spend_Band
ORDER BY web DESC;


-- ============================================================
-- Q6. Product spend by Age Band
-- ============================================================
SELECT Age_Band,
       ROUND(AVG(MntWines), 1)         AS wines,
       ROUND(AVG(MntFruits), 1)        AS fruits,
       ROUND(AVG(MntMeatProducts), 1)  AS meat,
       ROUND(AVG(MntFishProducts), 1)  AS fish,
       ROUND(AVG(MntSweetProducts), 1) AS sweets,
       ROUND(AVG(MntGoldProds), 1)     AS gold
FROM customers
GROUP BY Age_Band
ORDER BY Age_Band;


-- ============================================================
-- Q7. Under-served segments (high visits, low spend, low response)
-- ============================================================
SELECT Primary_Segment,
       COUNT(*)                                   AS customers,
       ROUND(AVG(Total_Spend), 0)                 AS avg_spend,
       ROUND(AVG(NumWebVisitsMonth), 1)           AS avg_visits,
       ROUND(100.0 * SUM(Response) / COUNT(*), 2) AS response_rate_pct
FROM customers
GROUP BY Primary_Segment
HAVING AVG(NumWebVisitsMonth) > 5
   AND AVG(Total_Spend) < (SELECT AVG(Total_Spend) FROM customers)
ORDER BY response_rate_pct ASC;


-- ============================================================
-- Q8. Window function: top-3 education groups by response rate
--     within each marital status
-- ============================================================
WITH edu_stats AS (
    SELECT Marital_Status, Education,
           COUNT(*)                                   AS customers,
           ROUND(100.0 * SUM(Response) / COUNT(*), 2) AS response_rate
    FROM customers
    GROUP BY Marital_Status, Education
)
SELECT * FROM (
    SELECT Marital_Status, Education, customers, response_rate,
           RANK() OVER (PARTITION BY Marital_Status
                        ORDER BY response_rate DESC) AS rnk
    FROM edu_stats
) WHERE rnk <= 3
ORDER BY Marital_Status, rnk;


-- ============================================================
-- Q9. Customer value deciles (NTILE)
-- ============================================================
WITH ranked AS (
    SELECT ID, Total_Spend, Response,
           NTILE(10) OVER (ORDER BY Total_Spend DESC) AS spend_decile
    FROM customers
)
SELECT spend_decile,
       COUNT(*)                                   AS customers,
       ROUND(AVG(Total_Spend), 0)                 AS avg_spend,
       ROUND(100.0 * SUM(Response) / COUNT(*), 2) AS response_rate_pct
FROM ranked
GROUP BY spend_decile
ORDER BY spend_decile;


-- ============================================================
-- Q10. "Ideal target customer" profile
-- ============================================================
SELECT Age_Band, Income_Band, Children,
       COUNT(*)                                   AS customers,
       ROUND(AVG(Total_Spend), 0)                 AS avg_spend,
       ROUND(100.0 * SUM(Response) / COUNT(*), 2) AS response_rate_pct
FROM customers
GROUP BY Age_Band, Income_Band, Children
HAVING COUNT(*) >= 20
ORDER BY response_rate_pct DESC
LIMIT 10;


-- ============================================================
-- VIEWS for the dashboard
-- ============================================================
DROP VIEW IF EXISTS vw_segment_kpis;
CREATE VIEW vw_segment_kpis AS
SELECT Primary_Segment,
       COUNT(*)                                   AS customers,
       ROUND(AVG(Income), 0)                      AS avg_income,
       ROUND(AVG(Age), 1)                         AS avg_age,
       ROUND(AVG(Total_Spend), 0)                 AS avg_spend,
       ROUND(AVG(Total_Purchases), 1)             AS avg_purchases,
       ROUND(AVG(NumWebVisitsMonth), 1)           AS avg_web_visits,
       ROUND(100.0 * SUM(Response) / COUNT(*), 2) AS response_rate_pct
FROM customers
GROUP BY Primary_Segment;

DROP VIEW IF EXISTS vw_campaign_kpis;
CREATE VIEW vw_campaign_kpis AS
SELECT 'AcceptedCmp1' AS campaign, SUM(AcceptedCmp1) AS acceptors,
       ROUND(100.0*SUM(AcceptedCmp1)/COUNT(*),2) AS rate_pct FROM customers
UNION ALL SELECT 'AcceptedCmp2', SUM(AcceptedCmp2), ROUND(100.0*SUM(AcceptedCmp2)/COUNT(*),2) FROM customers
UNION ALL SELECT 'AcceptedCmp3', SUM(AcceptedCmp3), ROUND(100.0*SUM(AcceptedCmp3)/COUNT(*),2) FROM customers
UNION ALL SELECT 'AcceptedCmp4', SUM(AcceptedCmp4), ROUND(100.0*SUM(AcceptedCmp4)/COUNT(*),2) FROM customers
UNION ALL SELECT 'AcceptedCmp5', SUM(AcceptedCmp5), ROUND(100.0*SUM(AcceptedCmp5)/COUNT(*),2) FROM customers
UNION ALL SELECT 'Response',     SUM(Response),     ROUND(100.0*SUM(Response)/COUNT(*),2)     FROM customers;