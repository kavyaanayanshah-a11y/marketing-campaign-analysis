-- =====================================================
-- Marketing Campaign Analysis : DDL
-- Engine: SQLite
-- =====================================================

DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
    ID                     INTEGER PRIMARY KEY,
    Year_Birth             INTEGER NOT NULL,
    Age                    INTEGER,
    Education              TEXT,
    Marital_Status         TEXT,
    Income                 REAL,
    Kidhome                INTEGER,
    Teenhome               INTEGER,
    Children               INTEGER,
    Country                TEXT,
    Dt_Customer            TEXT,
    Customer_Tenure_Days   INTEGER,
    Recency                INTEGER,

    MntWines               INTEGER,
    MntFruits              INTEGER,
    MntMeatProducts        INTEGER,
    MntFishProducts        INTEGER,
    MntSweetProducts       INTEGER,
    MntGoldProds           INTEGER,
    Total_Spend            REAL,

    NumDealsPurchases      INTEGER,
    NumWebPurchases        INTEGER,
    NumCatalogPurchases    INTEGER,
    NumStorePurchases      INTEGER,
    Total_Purchases        INTEGER,
    NumWebVisitsMonth      INTEGER,

    AcceptedCmp1           INTEGER,
    AcceptedCmp2           INTEGER,
    AcceptedCmp3           INTEGER,
    AcceptedCmp4           INTEGER,
    AcceptedCmp5           INTEGER,
    TotalAcceptedCmp       INTEGER,
    Response               INTEGER,
    Complain               INTEGER,

    Age_Band               TEXT,
    Income_Band            TEXT,
    Spend_Band             TEXT,

    IsHighIncome           INTEGER,
    IsYoung                INTEGER,
    IsResponder            INTEGER,
    IsHighWebEngagement    INTEGER,
    IsFamily               INTEGER,
    IsHighSpender          INTEGER,
    Primary_Segment        TEXT
);

CREATE INDEX idx_cust_segment ON customers(Primary_Segment);
CREATE INDEX idx_cust_country ON customers(Country);
CREATE INDEX idx_cust_income  ON customers(Income_Band);